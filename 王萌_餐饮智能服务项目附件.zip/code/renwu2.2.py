import pandas as pd
import random
pd.set_option('display.max_columns', None)   #显示完整的列
pd.set_option('display.max_rows', None)  #显示完整的行
data = pd.read_csv('meal_order_detail.csv')    # 用pandas读取的数据是dataframe类型的，便于数据预处理
data['dishes_name'] = data['dishes_name'].apply(lambda x: x.replace('\n','').replace('\r','').replace(' ',''))
data2 = pd.read_csv('meal_order_info.csv',encoding='gbk')

# 任务2.2：选取有效的订单数据
data3 = data2[~(data2['order_status'].isin([0]))]    # 删除data2['order_status']数值为0的那一行的数据
data3 = data3[~(data3['order_status'].isin([2]))]
# print(data3)
print(data3['order_status'].value_counts())
data4 = data2[~(data2['order_status'].isin([1]))]
id = data4['info_id'].values.tolist()
# print(id)
data5 = data
for i in id:
    data5 = data5[~(data['order_id'].isin([i]))]
print(data5)
newdata = data5[['order_id','dishes_name']]
a = newdata['dishes_name'].groupby(newdata['order_id'])
print(a)