# 任务3.2：构建训练集数据客户——菜品二元矩阵
import pandas as pd
import random
pd.set_option('display.max_columns', None)   #显示完整的列
pd.set_option('display.max_rows', None)  #显示完整的行

data = pd.read_csv('meal_order_detail.csv',)    # 用pandas读取的数据是dataframe类型的，便于数据预处理
data['dishes_name'] = data['dishes_name'].apply(lambda x: x.replace('\n','').replace('\r','').replace(' ',''))
data2 = pd.read_csv('meal_order_info.csv',encoding='gbk')
data4 = data2[~(data2['order_status'].isin([1]))]
id = data4['info_id']
data5 = data
for i in id:
    data5 = data5[~(data['order_id'].isin([i]))]
data6 = data5[['dishes_name','emp_id']]
emp_id = data6['emp_id']
emp_id_1 = emp_id.drop_duplicates()
emp_id_1_index = emp_id_1.index
emp_id_2 = emp_id_1.values.tolist()

# print(emp_id,len(emp_id))

data6 = data6.set_index('emp_id',drop = False)
import random
def split(full_list, shuffle=False, ratio=0.2):
    n_total = len(full_list)
    offset = int(n_total * ratio)
    if n_total == 0 or offset < 1:
        return [], full_list
    if shuffle:
        random.shuffle(full_list)
    test_id = full_list[:offset]
    train_id= full_list[offset:]
    return test_id, train_id
test_id, train_id = split(emp_id_2, shuffle=True, ratio=0.2)
# print(test_id, len(test_id))
# print(train_id, len(train_id))
train_dishes_name = data6['dishes_name'][train_id]
train_dishes_name_1 = pd.DataFrame(train_dishes_name)
train_dishes_name_1 = train_dishes_name_1.reset_index(drop = True)
train_id = train_dishes_name.index
train_id = pd.DataFrame(train_id)
train_data = pd.concat([train_id,train_dishes_name_1],axis = 1)
train_data.columns = ['emp_id','dishes_name']
train_data['counts'] = 1
test_dishes_name = data6['dishes_name'][test_id]
test_dishes_name_1 = pd.DataFrame(test_dishes_name)
test_dishes_name_1 = test_dishes_name_1.reset_index(drop = True)
test_id = test_dishes_name.index
test_id = pd.DataFrame(test_id)
test_data = pd.concat([test_id,test_dishes_name_1],axis = 1)
test_data.columns = ['emp_id','dishes_name']
test_data['counts'] = 1
# print(train_data)
# print(test_data)

train = pd.pivot_table(train_data,index=['emp_id'],values=['counts'],columns = ['dishes_name'])
train = train.fillna(0)
print(train)
