# 任务1.1：读取订单数据，并进行探索
import pandas as pd
import random
pd.set_option('display.max_columns', None)   #显示完整的列
pd.set_option('display.max_rows', None)  #显示完整的行
data = pd.read_csv('meal_order_detail.csv')    # 用pandas读取的数据是dataframe类型的，便于数据预处理
print(data)
print(data.keys())   # 输出每一列的列名