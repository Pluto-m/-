import pandas as pd
import random
pd.set_option('display.max_columns', None)   #显示完整的列
pd.set_option('display.max_rows', None)  #显示完整的行

# 任务1.4：绘制条形图展示热销Top10
import matplotlib.pyplot as plt
from pylab import mpl
mpl.rcParams['font.sans-serif'] = ['FangSong'] # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False # 解决保存图像是负号'-'显示为方块的问题
data = pd.read_csv('meal_order_detail.csv')    # 用pandas读取的数据是dataframe类型的，便于数据预处理
dn2 = data['dishes_name'].value_counts()    # 做频数统计
num_list = []
for i in range(0,10):
    num_list.append(dn2[i])
# print(num_list)
# print(dn2)
name_list = ['白饭/大碗', '凉拌菠菜', '谷稻小庄', '麻辣小龙虾 ','辣炒鱿鱼','芝士烩波士顿龙虾','五色糯米饭(七色)','白饭/小碗','香酥两吃大虾','焖猪手']
plt.bar(x = range(0,10,1), # 指定条形图x轴的刻度值
        height = num_list, # 指定条形图y轴的数值
        tick_label = name_list, # 指定条形图x轴的刻度标签
        color = 'steelblue', # 指定条形图的填充色
        width = 0.5
       )
plt.xticks(size='small',rotation=40,fontsize=8)
plt.ylabel('销量（个）')
plt.title('2016年8月热销菜品Top10')
for x,y in enumerate(num_list):
    plt.text(x,y+0.1,'%s' %round(y,1),ha='center')
plt.savefig('2016年8月热销菜品Top10.jpg')
plt.show()