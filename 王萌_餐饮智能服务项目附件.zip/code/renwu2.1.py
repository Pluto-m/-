import pandas as pd
import random
pd.set_option('display.max_columns', None)   #显示完整的列
pd.set_option('display.max_rows', None)  #显示完整的行

# 任务2.1：统计每个订单状态的占比
data2 = pd.read_csv('meal_order_info.csv',encoding='gbk')
# print(data2)
# print(data2.keys())   # 输出每一列的列名
order_status = data2['order_status']
os = order_status.value_counts()
os2 = round(os/os.sum(),4)
# print(order_status)
# print(os)
print(os2)